"""OSC TCP Package Initializer."""

from pythonosctcp.pythonosctcp import AsyncTCPClient, Dispatcher

print("OSC TCP package has been initialized!")
